TOKEN = "8193718328:AAEJ6EGaASUBTAzGt3_vr3Vm8zDBHnrcM3Q" # Токен бота 
CRYPTO = "28169726:973e04954a2ac8a86110f4f2a6ea27f1" # Токен CryptoBot 
ADMINS = [65764049, 65764049] # ID Админов 
 
# Bot Options 
bot_name = "رفع حرب" 
bot_logs = "-1002331984820" 
bot_channel_link = "https://t.me/+q-XXauy3kF00OTY0" 
bot_admin = "@h7arp, @zj_zl" 
bot_documentation = "https://t.me/+NLuU6CDoaz8yMmJk" 
bot_works = "https://t.me/+JGBx4JOfctIzMGQ0" 
bot_reviews = "https://t.me/+TPI_7G9wPHA4N2Y0
" 
 
 
# Price 
subscribe_1_day = 3 
subscribe_7_days = 10 
subscribe_14_days = 15 
subscribe_30_days = 25 
subscribe_365_days = 250 
subscribe_infinity_days = 400